# VYNOX

A responsive, zero-cost starter website with six browser-based generators.

## Included tools
- Caption Creator
- YouTube Title Lab
- Bio Builder
- Study Notes Helper
- Hashtag Mixer
- Image Prompt Maker

## Run locally
1. Extract `VYNOX-Website.zip`.
2. Open the `vynox` folder.
3. Open `index.html` in Chrome, Edge or Firefox.
4. Optional Google Fonts need internet; the tools themselves work without a server.

## Publish free with GitHub Pages
1. Create/sign in to GitHub: https://github.com/
2. Create a **public** repository named `vynox`.
3. Upload `index.html`, `styles.css`, and `app.js` to the repository root.
4. Open **Settings** → **Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then save.
7. Wait for publishing. Your URL will look like:
   `https://YOUR-USERNAME.github.io/vynox/`

Official guide:
https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## What this version does
The six tools use local JavaScript templates and run in the visitor's browser. They are not connected to a large-language-model AI service and do not need API keys, accounts or paid credits. The study helper produces a revision outline, not verified subject facts; check material against trusted textbooks or teacher notes.

## Privacy and responsible use
- Inputs are processed locally by this code and are not sent to a server.
- No analytics, ads, tracking or account system are included.
- Never place private API keys in public website code.
- Before adding ads, affiliate links, analytics, forms or a real AI API, review provider terms, privacy requirements and age rules with a parent/guardian.
- No income is guaranteed. Focus on useful tools and real visitors first.

## Customise
- `index.html`: page text and tool cards.
- `styles.css`: colours and layout.
- `app.js`: generator behaviour.
